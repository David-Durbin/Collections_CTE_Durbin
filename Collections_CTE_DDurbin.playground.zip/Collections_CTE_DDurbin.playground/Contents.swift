//: Playground - noun: a place where people can play

import UIKit

let rings: Dictionary<String, String> =
    ["Three": "Tres anuli regis Elveno sub caelo", "Seven": "Septem enim in aulis principum Chamaeacte lapideum", "Nine": "Novem per hominibus damnatuis mori"]

let onlyOne: [String] = ["Unus est solus", "Unus est solus", "Alia desertissima regione illa te facere"]

//print("The dictionary rings contains \(rings.count) items")

if let three = rings["Three"]
{
    print("The most ancient book of ancientness tells us that when the number Three is mentioned there are \"\(three)\"")
}

if let seven = rings["Seven"]
{
    print("The blessed book speaks also of the number Seven, \'\(seven)\"")
}

if let nine = rings["Nine"]
{
    print("It speaketh also of the number Nine, \"\(nine)\"")
}

print("But of the cursed number One it has only this to say: ")

for item in onlyOne
{
    print(item)
}



